package com.claudius;

import java.util.Set;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

public class ServletFilterConfigurator implements ServletContainerInitializer {

    public void onStartup(Set<Class<?>> c, ServletContext ctx) throws ServletException {
        System.out.println(">>>>>>>>>>>>>> registering filter for " + ctx.getContextPath());
        FilterRegistration fReg = ctx.addFilter("myGlobalFilter", com.claudius.MyGlobalFilter.class);
        fReg.addMappingForUrlPatterns(null, true, "/*");
    }

}

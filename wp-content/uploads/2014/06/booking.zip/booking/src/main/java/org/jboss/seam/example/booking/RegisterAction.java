//$Id: RegisterAction.java 5579 2007-06-27 00:06:49Z gavin $
package org.jboss.seam.example.booking;

import java.util.List;

import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;

@Stateful
@RequestScoped
@Named("register")
public class RegisterAction implements Register {
    

    @Inject
    private EntityManager em;

    private String verify;

    private boolean registered;

    private User user = new User();  
    
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String register() {
        FacesContext fc = FacesContext.getCurrentInstance();
        if (user.getPassword().equals(verify)) {
            Query query = em.createQuery("select u.username from User u where u.username=:user");
            query.setParameter("user", user.getUsername());
            List existing = query.getResultList();
            if (existing.size() == 0) {
                em.persist(user);
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Successfully registered as " + user.getUsername()));
                registered = true;
            } else {
                fc.addMessage("username",
                        new FacesMessage("Username " + user.getUsername() + " already exists"));
            }
        } else {
            fc.addMessage("verify", new FacesMessage("Re-enter your password"));
            verify = null;
        }
        fc.getExternalContext().getFlash().setKeepMessages(true);
        String page = registered ? "main?faces-redirect=true" : "#"; 
        return page;
    }

    public void invalid() {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Please try again"));
    }

    public boolean isRegistered() {
        return registered;
    }

    public String getVerify() {
        return verify;
    }

    public void setVerify(String verify) {
        this.verify = verify;
    }

    @Remove
    public void destroy() {
    }
}

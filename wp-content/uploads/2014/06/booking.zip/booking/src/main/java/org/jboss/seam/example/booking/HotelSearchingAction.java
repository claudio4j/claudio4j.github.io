//$Id: HotelSearchingAction.java 8998 2008-09-16 03:08:11Z shane.bryzak@jboss.com $
package org.jboss.seam.example.booking;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.enterprise.context.SessionScoped;
import javax.faces.model.ListDataModel;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateful
@SessionScoped
@Named
public class HotelSearchingAction implements  HotelSearching, Serializable
{
    
    private static final Logger log = Logger.getLogger(HotelSearchingAction.class.getName());
    
    @Inject
    private transient EntityManager em;
    
    private String searchString;
    private int pageSize = 10;
    private int page;
    private boolean nextPageAvailable;
   
    private transient ListDataModel<Hotel> hotels;
   
    public void find() 
    {
        log.info("find");
        page = 0;
        queryHotels();
    }

    public void nextPage() 
    {
        log.info("nextPage");
        page++;
        queryHotels();
    }
    
    private ListDataModel<Hotel> queryHotels() {
        TypedQuery<Hotel> query = em.createQuery("select h from Hotel h "
                + "where lower(h.name) like :searchPattern " 
                + " or lower(h.city) like :searchPattern " 
                + " or lower(h.zip) like :searchPattern " 
                + " or lower(h.address) like :searchPattern ", Hotel.class);
        String value = searchString==null ? 
                "%" : 
                '%' + searchString.toLowerCase().replace('*', '%') + '%';
        query.setParameter("searchPattern", value);
        
        List<Hotel> results = query.setMaxResults(pageSize+1)
                                .setFirstResult(page * pageSize)
                                .getResultList();
        
        nextPageAvailable = results.size() > pageSize;
        if (nextPageAvailable) 
        {
            hotels = new ListDataModel<Hotel>(new ArrayList<Hotel>(results.subList(0,pageSize)));
        } else {
            hotels = new ListDataModel<Hotel>(results);
        }
        return hotels;
        
    }
    
    public ListDataModel<Hotel> getHotels() {
        return hotels;
    }

    public boolean isNextPageAvailable()
    {
        return nextPageAvailable;
    }
   
   public int getPageSize() {
      return pageSize;
   }
   
   public void setPageSize(int pageSize) {
      this.pageSize = pageSize;
   }
   
   public String getSearchString()
   {
      return searchString;
   }
   
   public void setSearchString(String searchString)
   {
      this.searchString = searchString;
   }
   
   @Remove
   public void destroy() {}
}

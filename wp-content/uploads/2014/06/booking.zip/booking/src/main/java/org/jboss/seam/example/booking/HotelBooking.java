//$Id: HotelBooking.java 5579 2007-06-27 00:06:49Z gavin $
package org.jboss.seam.example.booking;

import javax.ejb.Local;

@Local
public interface HotelBooking
{
   public String selectHotel(Hotel selectedHotel);
   
   public String bookHotel();
   
   public String setBookingDetails();
   public boolean isBookingValid();
   public Booking getBooking();
   
   public String confirm();
   
   public String cancel();
   
   public void destroy();
   public Hotel getHotel();
   
}
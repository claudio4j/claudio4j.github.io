//$Id: BookingList.java 5579 2007-06-27 00:06:49Z gavin $
package org.jboss.seam.example.booking;

import javax.ejb.Local;
import javax.faces.model.ListDataModel;

@Local
public interface BookingList
{
   public ListDataModel<Booking> getBookings();
   public Booking getBooking();
   public String cancel(Booking booking);
   public void updateBookingList(BookingEvent bookingEvent);
   public void destroy();
}
//$Id: BookingListAction.java 8748 2008-08-20 12:08:30Z pete.muir@jboss.org $
package org.jboss.seam.example.booking;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.ListDataModel;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

@Stateful
@SessionScoped
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
@Named("bookingList")
public class BookingListAction implements BookingList, Serializable
{
   private static final long serialVersionUID = 1L;
   
   @Inject
   private EntityManager em;
   
   @Inject
   @Named("loggedUser")
   private User user;
   
   private ListDataModel<Booking> bookings;
   
   private static final Logger log = Logger.getLogger(BookingListAction.class.getName()); 
   
   @Produces
   @Named("bookings")
   @RequestScoped
   public ListDataModel<Booking> getBookings()
   {
       if (bookings == null)
           updateBookingList(null);

        return bookings;
   }

   public void updateBookingList(@Observes BookingEvent bookingEvent)
   {
       List<Booking> _results = new ArrayList<Booking>(0);
       _results = em.createQuery("select b from Booking b where b.user.username = :username order by b.checkinDate", Booking.class)
            .setParameter("username", user.getUsername())
                .getResultList();
       bookings = new ListDataModel<Booking>(_results);
       log.info("bookings found list size: " + _results.size());
   }
   
   public String cancel(Booking booking)
   {
      log.info("Cancel booking: " + booking.getId() + " for " + user.getUsername());
      Booking cancelled = em.find(Booking.class, booking.getId());
      if (cancelled!=null) em.remove( cancelled );
      updateBookingList(null);
      FacesContext fc = FacesContext.getCurrentInstance();
      fc.getExternalContext().getFlash().setKeepMessages(true);
      fc.addMessage(null, new FacesMessage("Booking cancelled for confirmation number " + booking.getId()));
      return "main?faces-redirect=true";
   }
   
   public Booking getBooking()
   {
      return bookings.getRowData();
   }
   
   @Remove
   public void destroy() {}
}

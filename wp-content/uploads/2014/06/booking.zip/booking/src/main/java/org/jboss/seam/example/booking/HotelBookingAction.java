//$Id: HotelBookingAction.java 5579 2007-06-27 00:06:49Z gavin $
package org.jboss.seam.example.booking;

import java.io.Serializable;
import java.util.Calendar;
import java.util.logging.Logger;

import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.enterprise.event.Event;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

@Stateful
@Named("hotelBooking")
@ConversationScoped
public class HotelBookingAction  implements HotelBooking, Serializable {

    private static final Logger LOG = Logger.getLogger(HotelBookingAction.class.getName());
    
    @Inject
    private EntityManager em;

    @Inject
    @Named("loggedUser")
    private User user;

    private Hotel hotel;

    private Booking booking;

    @Inject
    private Event<BookingEvent> bookingevent;

    @Inject
    Conversation conversation;

    private boolean bookingValid;

    public String selectHotel(Hotel selectedHotel) {
        LOG.info("selectHotel: " + selectedHotel);
        hotel = em.merge(selectedHotel);
        if (conversation.isTransient())
            conversation.begin();

        return "hotel?faces-redirect=true";
    }

    public Hotel getHotel() {
        return hotel;
    }

    public String bookHotel() {
        booking = new Booking(hotel, user);
        Calendar calendar = Calendar.getInstance();
        booking.setCheckinDate(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        booking.setCheckoutDate(calendar.getTime());
        
        return "book?faces-redirect=true";
    }

    public String setBookingDetails() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        String redirectPage = "#";
        if (booking.getCheckinDate().before(calendar.getTime())) {
            FacesContext.getCurrentInstance().addMessage("checkinDate", new FacesMessage("Check in date must be a future date"));
            bookingValid = false;
        } else if (!booking.getCheckinDate().before(booking.getCheckoutDate())) {
            FacesContext.getCurrentInstance().addMessage("checkoutDate",
                    new FacesMessage("Check out date must be later than check in date"));
            bookingValid = false;
        } else {
            bookingValid = true;
            redirectPage = "confirm?faces-redirect=true";
        }
        return redirectPage;
    }

    public Booking getBooking() {
        return booking;
    }
    
    public boolean isBookingValid() {
        return bookingValid;
    }

    public String confirm() {
        em.persist(booking);
        LOG.info("New booking: " + booking.getId() + " for " + user.getUsername());
        if (!conversation.isTransient())
            conversation.end();
        bookingevent.fire(new BookingEvent());
        FacesContext fc = FacesContext.getCurrentInstance();
        fc.getExternalContext().getFlash().setKeepMessages(true);
        fc.addMessage(null,
                new FacesMessage("Thank you, " + user.getName() + ", your confimation number for " +  hotel.getName()+ " is " + booking.getId()));
        return "main?faces-redirect=true";
    }

    public String cancel() {
        if (!conversation.isTransient())
            conversation.end();
        return "main?faces-redirect=true";
    }

    @Remove
    public void destroy() {
    }
}
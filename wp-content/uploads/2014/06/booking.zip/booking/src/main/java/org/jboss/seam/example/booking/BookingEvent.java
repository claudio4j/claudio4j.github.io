package org.jboss.seam.example.booking;

public class BookingEvent {

}

//$Id: ChangePasswordAction.java 5579 2007-06-27 00:06:49Z gavin $
package org.jboss.seam.example.booking;

import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

@Stateful
@RequestScoped
@Named("changePassword")
public class ChangePasswordAction implements ChangePassword
{
   @Inject
   @Named("loggedUser")
   private User user;
   
   @Inject
   private EntityManager em;
   
   private String verify;
   
   private boolean changed;
   
   public String changePassword()
   {
      FacesContext fc = FacesContext.getCurrentInstance();
      String page = "main?faces-redirect=true";
      if ( user.getPassword().equals(verify) )
      {
         // find the user, as the current injected is a proxy, not an entity.
         revertUser();
         user.setPassword(verify);
         user = em.merge(user);
         fc.addMessage(null, new FacesMessage("Password updated"));
         changed = true;
      }
      else 
      {
         fc.addMessage("verify", new FacesMessage("Re-enter new password"));
         revertUser();
         verify=null;
         page = "#";
      }
      
      fc.getExternalContext().getFlash().setKeepMessages(true);
      return page;
   }
   
   public boolean isChanged()
   {
      return changed;
   }
   
   private void revertUser()
   {
      user = em.find(User.class, user.getUsername());
   }
   public String getVerify()
   {
      return verify;
   }
   public void setVerify(String verify)
   {
      this.verify = verify;
   }
   
   @Remove
   public void destroy() {}
}

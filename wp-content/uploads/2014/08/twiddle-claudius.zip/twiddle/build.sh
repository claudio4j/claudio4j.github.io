#!/bin/bash

JBOSS_HOME=/opt/jboss-eap-5.2/jboss-as

# backup twiddle.jar

BKP=$JBOSS_HOME/bin/orig-twiddle.jar.rej
if [[ ! -f $BKP ]] ; then
  echo Do a backup of twiddle.jar at $BKP
  cp $JBOSS_HOME/bin/twiddle.jar $BKP
  echo
  echo Remove signatures of $JBOSS_HOME/bin/twiddle.jar
  zip -d $JBOSS_HOME/bin/twiddle.jar META-INF/JBOSSCOD.SF META-INF/JBOSSCOD.RSA META-INF/MANIFEST.MF
  echo
fi

CP=$JBOSS_HOME/bin/run.jar
CP=$CP:$JBOSS_HOME/bin/twiddle.jar
CP=$CP:$JBOSS_HOME/lib/jboss-logging-spi.jar
CP=$CP:$JBOSS_HOME/lib/jboss-common-core.jar

echo Compile
javac -d classes/ \
  -classpath $CP \
  -sourcepath src/main/  \
  src/main/org/jboss/console/twiddle/command/GetCommand.java 
  
echo
echo Package
jar uvf $JBOSS_HOME/bin/twiddle.jar -C classes/ .


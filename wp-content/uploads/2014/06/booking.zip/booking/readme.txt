Author: Claudio Miranda <claudio@claudius.com.br>
Date  : 19/Jun/2014

http://claudius.com.br/2014/06/migration-from-jboss-seam-2-2-to-java-ee-7/
